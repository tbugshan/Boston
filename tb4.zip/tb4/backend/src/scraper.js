const cheerio = require('cheerio');
const request = require('request');

var scraper = {};

scraper.getRestaurants = function(page) {
  var results = [];

  return new Promise(function(resolve, reject) {

    if(page == 0){
      request('https://www.yelp.com/search?find_desc=Restaurants&find_loc=Boston,+MA',
      function (err, response, html) {
        if(!err && response.statusCode == 200){
          var $ = cheerio.load(html);
          readDetails($,results);
          resolve(results);
        }else{
          reject(Error(response.statusCode));
        }
      })
    }else{
      request('https://www.yelp.com/search?find_desc=Restaurants&find_loc=Boston,+MA&start='+page*10,
      function (err, response, html) {
        if(!err && response.statusCode == 200){
          var $ = cheerio.load(html);
          readDetails($,results);
          resolve(results);
        }else{
          reject(Error(response.statusCode));
        }
      })
    }

  });
}

scraper.getHotels = function(page) {
  var results = [];

  return new Promise(function(resolve, reject) {

    if(page == 0){
      request('https://www.yelp.com/search?find_desc=Hotels&find_loc=Boston,+MA&start=0',
      function (err, response, html) {
        if(!err && response.statusCode == 200){
          var $ = cheerio.load(html);
          readDetails($,results);
          resolve(results);
        }else{
          reject(Error(response.statusCode));
        }
      })
    }else{
      request('https://www.yelp.com/search?find_desc=Hotels&find_loc=Boston,+MA&start='+page*10,
      function (err, response, html) {
        if(!err && response.statusCode == 200){
          var $ = cheerio.load(html);
          readDetails($,results);
          resolve(results);
        }else{
          reject(Error(response.statusCode));
        }
      })
    }

  });
}

function readDetails($,resultsArray) {
  $('li.regular-search-result').each(function (i, element) {

    var title = $(this).children().first()
      .children().first()
      .children().first()
      .children().first()
      .children().last()
      .children().first()
      .children().first()
      .children().first().text();

    var rating = $(this).children().first()
      .children().first()
      .children().first()
      .children().first()
      .children().last()
      .children().eq(1)
      .children().first().attr('title').split(' ')[0];

    var reviewCount = $(this).children().first()
      .children().first()
      .children().first()
      .children().first()
      .children().last()
      .children().eq(1)
      .children().last().text().replace(/\n/g,'').trim().split(' ')[0];

    var address = $(this).children().first()
      .children().first()
      .children().last()
      .children().eq(1).text().replace(/\n/g,'').trim();

    resultsArray.push({name: title, rating: rating, reviews: reviewCount, address: address});
  })
}

module.exports = scraper;
