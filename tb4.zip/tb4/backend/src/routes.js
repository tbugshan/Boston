const express = require('express');
const scraper = require('./scraper');
var router = express.Router();

router.get('/restaurants/:page', function(request, response) {
  scraper.getRestaurants(request.params.page - 1)
    .then(function(resp) {
      response.status(200).json(resp)
    })
});

router.get('/hotels/:page', function(request, response) {
  scraper.getHotels(request.params.page - 1)
    .then(function(resp) {
      response.status(200).json(resp)
    })
})

router.get('/restaurants/:id/ratings', function(req, res) {
  var counts = {
    oneToThree: 0,
    threeToFour: 0,
    aboveFour: 0
  }

  scraper.getRestaurants(req.params.id-1)
    .then(function(resp) {
      resp.forEach(function(value, index, resp) {
        if (value.rating > 0 && value.rating <= 3) {
          counts.oneToThree++;
        } else if (value.rating > 3 && value.rating <= 4) {
          counts.threeToFour++;
        } else {
          counts.aboveFour++;
        }
      })

      var total = counts.oneToThree + counts.threeToFour + counts.aboveFour;


      var percentages = [
            {label:'1-3 star', value:(counts.oneToThree / total) * 100},
            {label:'3-4 star', value:(counts.threeToFour / total) * 100},
            {label:'above 4 stars', value:(counts.aboveFour / total) * 100}
          ]

      res.status(200).json(percentages);
    })


})

router.get('/hotels/:id/ratings', function(req, res) {
  var counts = {
    oneToThree: 0,
    threeToFour: 0,
    aboveFour: 0
  }

  scraper.getHotels(req.params.id-1)
    .then(function(resp) {
      resp.forEach(function(value, index, resp) {
        if (value.rating > 0 && value.rating <= 3) {
          counts.oneToThree++;
        } else if (value.rating > 3 && value.rating <= 4) {
          counts.threeToFour++;
        } else {
          counts.aboveFour++;
        }
      })

      var total = counts.oneToThree + counts.threeToFour + counts.aboveFour;


      var percentages = [
            {label:'1-3 star', value:(counts.oneToThree / total) * 100},
            {label:'3-4 star', value:(counts.threeToFour / total) * 100},
            {label:'above 4 stars', value:(counts.aboveFour / total) * 100}
          ]

      res.status(200).json(percentages);
    })


})

router.get('/restaurants/:id/reviews', function(req, res) {
  var counts = {
    a: 0, //1-1000
    b: 0, //1001-2000
    c: 0, //2001-3000
    d: 0  //above 3000
  }

  scraper.getRestaurants(req.params.id-1)
    .then(function(resp) {
      resp.forEach(function(value, index, resp) {
        if (value.reviews > 0 && value.reviews <= 1000) {
          counts.a++;
        } else if (value.reviews > 1000 && value.reviews <= 2000) {
          counts.b++;
        } else if (value.reviews > 2000 && value.reviews <= 3000) {
          counts.c++;
        }else{
          counts.d++;
        }
      })

      var percentages = [
            {x:'1-1000', y:counts.a},
            {x:'1001-2000', y:counts.b},
            {x:'2001-3000', y:counts.c},
            {x:'3000+', y:counts.d}
          ]

      res.status(200).json(percentages);
    })


})

router.get('/hotels/:id/reviews', function(req, res) {
  var counts = {
    a: 0, //1-100
    b: 0, //101-200
    c: 0, //201-300
    d: 0  //above 300
  }

  scraper.getHotels(req.params.id-1)
    .then(function(resp) {
      resp.forEach(function(value, index, resp) {
        if (value.reviews > 0 && value.reviews <= 100) {
          counts.a++;
        } else if (value.reviews > 100 && value.reviews <= 200) {
          counts.b++;
        } else if (value.reviews > 200 && value.reviews <= 300) {
          counts.c++;
        }else{
          counts.d++;
        }
      })

      var percentages = [
            {x:'1-100', y:counts.a},
            {x:'101-200', y:counts.b},
            {x:'201-300', y:counts.c},
            {x:'300+', y:counts.d}
          ]

      res.status(200).json(percentages);
    })


})

module.exports = router;
