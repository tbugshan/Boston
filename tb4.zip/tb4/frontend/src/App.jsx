import React from 'react';
import { Navbar } from "react-bootstrap";
import { Nav } from 'react-bootstrap';
import { NavItem } from 'react-bootstrap';
import rd3 from "rd3";

import ReviewChart from './RestaurantReviewChart.jsx';
import RestaurantRatings from './RestaurantRatingsChart.jsx'
import HotelRating from './HotelRatings.jsx';
import HotelReviewChart from './HotelReviewChart.jsx';

const PieChart = rd3.PieChart;

class App extends React.Component {

    constructor() {
        super();
        this.state = { 
            data: [
                {label:'1-3 star', value:0},
                {label:'3-4 star', value:0},
                {label:'above 4 stars', value:0}]
        };
    }

    componentDidMount() {
        var _this = this;

        fetch('http://localhost:3000/restaurants/1/ratings')
            .then(results => results.json())
            .then(function(res){
                _this.setState({data: res})
            });
    }

    render() {
        return (
            <div>
                <Navbar>
                    <Navbar.Header>
                        <Navbar.Brand>
                            <a href="#">Dashboard</a>
                        </Navbar.Brand>
                    </Navbar.Header>
                    <Nav>
                        <NavItem eventKey={1} href="#" className="active">Restaurants & Hotels</NavItem>
                    </Nav>
                </Navbar>

                <div className="text-center">
                    <div className="col-md-6">
                        <RestaurantRatings/>
                    </div>
                    <div className="col-md-6">
                        <HotelRating/>
                    </div>

                    <div className="col-md-6">
                        <ReviewChart/>
                    </div>
                    
                    <div className="col-md-6">
                        <HotelReviewChart/>
                    </div>
                </div>
            </div>

        );
    }
}
export default App;