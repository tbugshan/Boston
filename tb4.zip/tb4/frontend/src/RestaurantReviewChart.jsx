import React from "react";
import ReactDOM from 'react-dom';
import rd3 from "rd3";

const BarChart = rd3.BarChart;

class ReviewChart extends React.Component{

    constructor(){
        super();
        this.state = {
            data:[{
                name: 'Reviews',
                values: [{x:'1-1000', y:0},
                {x:'1001-2000', y:0},
                {x:'2001-3000', y:0},
                {x:'3000+', y:0}]
            }]
        }
    }

    componentDidMount(){
        var _this = this;

        fetch('http://localhost:3000/restaurants/1/reviews')
        .then(results => results.json())
        .then(function(res){
            _this.setState({data: [{name: 'Reviews', values: res}]});
        })
    }

    render(){
        return (
            <div>
                <BarChart
                    data={this.state.data}
                    width={400}
                    height={400}
                    title="Review Distribution in Restaurants"
                    xAxisLabel="No. of Reviews"
                    yAxisLabel="No. of Restaurants"
                />
            </div>
        );
    }
}

export default ReviewChart;