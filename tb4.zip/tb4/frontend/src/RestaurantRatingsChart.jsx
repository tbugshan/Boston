import React from 'react';
import rd3 from 'rd3';

const PieChart = rd3.PieChart;

class RestaurantRatings extends React.Component {

    constructor() {
        super();
        this.state = {
            data: [{ label: '1-3 star', value: 0 },
            { label: '3-4 star', value: 0 },
            { label: 'above 4 stars', value: 0 }]
        }
    }

    componentDidMount() {
        var _this = this;

        fetch('http://localhost:3000/restaurants/1/ratings')
            .then(results => results.json())
            .then(function (res) {
                _this.setState({ data: res })
            });
    }

    render() {
        return (
            <PieChart
                data={this.state.data}
                width={400}
                height={400}
                radius={100}
                innerRadius={20}
                sectorBorderColor="white"
                title="Distribution of ratings in Restaurants"
            />
        )
    }
}

export default RestaurantRatings;