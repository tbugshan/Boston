import React from "react";
import ReactDOM from 'react-dom';
import rd3 from "rd3";

const BarChart = rd3.BarChart;

class HotelReviewChart extends React.Component{

    constructor(){
        super();
        this.state = {
            data:[{
                name: 'Reviews',
                values: [{x:'1-100', y:0},
                {x:'101-200', y:0},
                {x:'201-3000', y:0},
                {x:'300+', y:0}]
            }]
        }
    }

    componentDidMount(){
        var _this = this;

        fetch('http://localhost:3000/hotels/1/reviews')
        .then(results => results.json())
        .then(function(res){
            _this.setState({data: [{name: 'Review Distribution in Hotels', values: res}]});
        })
    }

    render(){
        return (
            <div>
                <BarChart
                    data={this.state.data}
                    width={400}
                    height={400}
                    title="Review Distribution in Hotels"
                    xAxisLabel="No. of Reviews"
                    yAxisLabel="No. of Restaurants"
                />
            </div>
        );
    }
}

export default HotelReviewChart;